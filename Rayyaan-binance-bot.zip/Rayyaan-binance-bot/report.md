# Report

This short report explains design choices and includes sample screenshots you can add later.

## Validation & Logging
- Validation of symbol, side, quantity in `src/validators.py`.
- Centralized rotating file logger in `src/logger.py` writes to `bot.log`.
- Each order call logs the action before sending.

## Basic Orders
- Market and Limit supported via `src/market_orders.py` and `src/limit_orders.py`.

## Advanced Orders
- OCO is emulated for futures using a TAKE_PROFIT and STOP_MARKET pair.
- TWAP splits a total quantity into N market orders over a time window.

## How to Test
- Use `--dry` to simulate without contacting the API.
- For live testnet, set `BINANCE_FUTURES_TESTNET=True` and provide API keys.

Add execution screenshots here.
