from __future__ import annotations

import click
from rich import print

from .client import BinanceFuturesClient
from .validators import validate_symbol
from .logger import get_logger


@click.group(help="Utility commands: ping, open-orders, cancel-all")
def cli():
    pass


@cli.command("ping", help="Check API connectivity by fetching server time")
def ping():
    log = get_logger("manage")
    c = BinanceFuturesClient()
    try:
        # Prefer time(); fall back to exchange_info() if needed
        try:
            resp = c.client.time()
        except Exception:
            resp = c.client.exchange_info()
        print({"ok": True, "result": resp})
        log.info("Ping succeeded")
    except Exception as e:
        log.exception("Ping failed")
        raise


@cli.command("open-orders", help="List open orders for a symbol")
@click.argument("symbol")
def open_orders(symbol: str):
    log = get_logger("manage")
    c = BinanceFuturesClient()
    symbol = validate_symbol(symbol)
    try:
        resp = c.client.get_open_orders(symbol=symbol)
        print(resp)
        log.info(f"Fetched open orders for {symbol}: {len(resp)}")
    except Exception:
        log.exception("Failed to fetch open orders")
        raise


@cli.command("cancel-all", help="Cancel all open orders for a symbol")
@click.argument("symbol")
@click.option("--dry", is_flag=True)
def cancel_all(symbol: str, dry: bool):
    log = get_logger("manage")
    c = BinanceFuturesClient()
    symbol = validate_symbol(symbol)
    if dry:
        log.info(f"DRY Cancel all orders for {symbol}")
        print({"dry": True, "action": "cancel_all", "symbol": symbol})
        return
    try:
        resp = c.client.cancel_all_open_orders(symbol=symbol)
        print(resp)
        log.info(f"Cancelled all orders for {symbol}")
    except Exception:
        log.exception("Failed to cancel all orders")
        raise


@cli.command("set-leverage", help="Set leverage for a symbol, e.g. 10")
@click.argument("symbol")
@click.argument("leverage", type=int)
def set_leverage(symbol: str, leverage: int):
    log = get_logger("manage")
    c = BinanceFuturesClient()
    symbol = validate_symbol(symbol)
    try:
        resp = c.client.change_leverage(symbol=symbol, leverage=leverage)
        print(resp)
        log.info(f"Set leverage {leverage} for {symbol}")
    except Exception:
        log.exception("Failed to set leverage")
        raise


@cli.command("set-margin", help="Set margin type: ISOLATED or CROSSED")
@click.argument("symbol")
@click.argument("margin", type=click.Choice(["ISOLATED", "CROSSED"], case_sensitive=False))
def set_margin(symbol: str, margin: str):
    log = get_logger("manage")
    c = BinanceFuturesClient()
    symbol = validate_symbol(symbol)
    try:
        resp = c.client.change_margin_type(symbol=symbol, marginType=margin.upper())
        print(resp)
        log.info(f"Set margin {margin} for {symbol}")
    except Exception:
        log.exception("Failed to set margin type")
        raise


if __name__ == "__main__":
    cli()
