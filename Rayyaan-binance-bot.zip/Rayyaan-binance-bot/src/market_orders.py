from __future__ import annotations

import click
from rich import print

from .client import BinanceFuturesClient
from .validators import validate_symbol, validate_qty, validate_side
from .config import load_settings
from .logger import get_logger


@click.command(help="Place a market order on Binance USDT-M Futures")
@click.argument("symbol", required=False)
@click.argument("side", required=False)
@click.argument("qty", required=False, type=float)
@click.option("--dry", is_flag=True, help="Dry run: validate and log without sending")
def cli(symbol: str | None, side: str | None, qty: float | None, dry: bool):
    s = load_settings()
    symbol = validate_symbol(symbol or s.default_symbol)
    side = validate_side(side or "BUY")
    qty = validate_qty(qty or s.default_qty)

    log = get_logger("market")
    client = BinanceFuturesClient()
    if dry:
        log.info(f"DRY MARKET {side} {symbol} qty={qty}")
        print(f"[yellow]Dry run: MARKET {side} {symbol} qty={qty}")
        return

    resp = client.market_order(symbol, side, qty)
    print({"status": "ok", "response": resp})


if __name__ == "__main__":
    cli()
