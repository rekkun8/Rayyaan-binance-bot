from __future__ import annotations

from typing import Any, Dict

from binance.um_futures import UMFutures

from .config import load_settings
from .logger import get_logger
from .exchange import adjust_price, adjust_qty


class BinanceFuturesClient:
    """Thin wrapper around python-binance UMFutures with logging.

    Uses env-based settings and supports testnet.
    """

    def __init__(self) -> None:
        self.settings = load_settings()
        self.log = get_logger("client")
        self.client = UMFutures(
            key=self.settings.api_key,
            secret=self.settings.api_secret,
            base_url=(
                "https://testnet.binancefuture.com" if self.settings.testnet else "https://fapi.binance.com"
            ),
        )

    # --- basic orders ---
    def market_order(self, symbol: str, side: str, quantity: float) -> Dict[str, Any]:
        self.log.info(f"MARKET {side} {symbol} qty={quantity}")
        try:
            adj_qty = adjust_qty(self.client, symbol, quantity, market=True)
            return self.client.new_order(symbol=symbol, side=side, type="MARKET", quantity=adj_qty)
        except Exception:
            self.log.exception("Failed to place MARKET order")
            raise

    def limit_order(self, symbol: str, side: str, quantity: float, price: float, time_in_force: str = "GTC") -> Dict[str, Any]:
        self.log.info(f"LIMIT {side} {symbol} qty={quantity} price={price}")
        try:
            adj_price = adjust_price(self.client, symbol, price)
            adj_qty = adjust_qty(self.client, symbol, quantity)
            return self.client.new_order(
                symbol=symbol,
                side=side,
                type="LIMIT",
                quantity=adj_qty,
                price=adj_price,
                timeInForce=time_in_force,
            )
        except Exception:
            self.log.exception("Failed to place LIMIT order")
            raise

    # --- advanced examples ---
    def stop_limit(self, symbol: str, side: str, quantity: float, price: float, stop_price: float, tif: str = "GTC") -> Dict[str, Any]:
        self.log.info(f"STOP-LIMIT {side} {symbol} qty={quantity} price={price} stop={stop_price}")
        try:
            adj_price = adjust_price(self.client, symbol, price)
            adj_stop = adjust_price(self.client, symbol, stop_price)
            adj_qty = adjust_qty(self.client, symbol, quantity)
            return self.client.new_order(
                symbol=symbol,
                side=side,
                type="STOP",
                quantity=adj_qty,
                price=adj_price,
                stopPrice=adj_stop,
                timeInForce=tif,
                workingType="MARK_PRICE",
            )
        except Exception:
            self.log.exception("Failed to place STOP-LIMIT order")
            raise

    def oco_take_profit_stop_loss(self, symbol: str, side: str, quantity: float, tp_price: float, sl_price: float) -> Dict[str, Any]:
        """Simplified OCO-like behavior for futures using two orders.
        Note: UMFutures doesn't support classic spot OCO; we emulate with TP/SL.
        """
        self.log.info(
            f"OCO-like {side} {symbol} qty={quantity} tp={tp_price} sl={sl_price} (emulated with two orders)"
        )
        # For futures, use TAKE_PROFIT and STOP_MARKET
        try:
            tp = self.client.new_order(
                symbol=symbol,
                side=("SELL" if side == "BUY" else "BUY"),
                type="TAKE_PROFIT",
                stopPrice=tp_price,
                closePosition=True,
                workingType="MARK_PRICE",
            )
            sl = self.client.new_order(
                symbol=symbol,
                side=("SELL" if side == "BUY" else "BUY"),
                type="STOP_MARKET",
                stopPrice=sl_price,
                closePosition=True,
                workingType="MARK_PRICE",
            )
        except Exception:
            self.log.exception("Failed to place OCO-like orders")
            raise
        return {"take_profit": tp, "stop_loss": sl}
