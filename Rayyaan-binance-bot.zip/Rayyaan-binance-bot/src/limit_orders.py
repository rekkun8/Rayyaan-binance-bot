from __future__ import annotations

import click
from rich import print

from .client import BinanceFuturesClient
from .validators import validate_symbol, validate_qty, validate_side
from .logger import get_logger


@click.command(help="Place a limit order on Binance USDT-M Futures")
@click.argument("symbol")
@click.argument("side")
@click.argument("qty", type=float)
@click.argument("price", type=float)
@click.option("--tif", default="GTC", show_default=True, help="Time in force: GTC/IOC/FOK")
@click.option("--dry", is_flag=True, help="Dry run: validate and log without sending")
def cli(symbol: str, side: str, qty: float, price: float, tif: str, dry: bool):
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    qty = validate_qty(qty)

    log = get_logger("limit")
    client = BinanceFuturesClient()
    if dry:
        log.info(f"DRY LIMIT {side} {symbol} qty={qty} price={price} tif={tif}")
        print(f"[yellow]Dry run: LIMIT {side} {symbol} qty={qty} price={price} tif={tif}")
        return

    resp = client.limit_order(symbol, side, qty, price, time_in_force=tif)
    print({"status": "ok", "response": resp})


if __name__ == "__main__":
    cli()
