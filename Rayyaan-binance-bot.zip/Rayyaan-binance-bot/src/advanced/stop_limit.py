from __future__ import annotations

import click
from rich import print

from ..client import BinanceFuturesClient
from ..validators import validate_symbol, validate_side, validate_qty
from ..logger import get_logger


@click.command(help="Stop-Limit order: place a limit order that is triggered by a stop price")
@click.argument("symbol")
@click.argument("side")
@click.argument("qty", type=float)
@click.argument("price", type=float)
@click.argument("stop_price", type=float)
@click.option("--tif", default="GTC", show_default=True)
@click.option("--dry", is_flag=True)
def cli(symbol: str, side: str, qty: float, price: float, stop_price: float, tif: str, dry: bool):
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    qty = validate_qty(qty)

    log = get_logger("stop_limit")
    client = BinanceFuturesClient()
    if dry:
        log.info(f"DRY STOP-LIMIT {side} {symbol} qty={qty} price={price} stop={stop_price} tif={tif}")
        print(f"[yellow]Dry run: STOP-LIMIT {side} {symbol} qty={qty} price={price} stop={stop_price} tif={tif}")
        return

    resp = client.stop_limit(symbol, side, qty, price, stop_price, tif)
    print({"status": "ok", "response": resp})


if __name__ == "__main__":
    cli()
