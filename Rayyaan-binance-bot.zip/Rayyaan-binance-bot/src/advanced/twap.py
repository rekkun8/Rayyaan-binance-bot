from __future__ import annotations

import math
import time
from typing import Iterable

import click
from rich import print

from ..client import BinanceFuturesClient
from ..validators import validate_symbol, validate_qty, validate_side
from ..logger import get_logger


@click.command(help="TWAP: split a market order into N slices over duration")
@click.argument("symbol")
@click.argument("side")
@click.argument("qty", type=float)
@click.option("--slices", default=5, show_default=True, type=int)
@click.option("--duration", default=60, show_default=True, type=int, help="Seconds to spread execution")
@click.option("--dry", is_flag=True)
def cli(symbol: str, side: str, qty: float, slices: int, duration: int, dry: bool):
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    qty = validate_qty(qty)

    log = get_logger("twap")
    client = BinanceFuturesClient()
    per = qty / max(slices, 1)
    interval = duration / max(slices, 1)

    log.info(f"TWAP {side} {symbol} total={qty} slices={slices} per_slice={per:.6f} interval={interval:.2f}s")
    print(f"TWAP {side} {symbol} total={qty} slices={slices} per_slice={per:.6f} interval={interval:.2f}s")

    if dry:
        return

    for i in range(slices):
        resp = client.market_order(symbol, side, per)
        print({"slice": i + 1, "response": resp})
        if i < slices - 1:
            time.sleep(interval)


if __name__ == "__main__":
    cli()
