from __future__ import annotations

import click
from rich import print

from ..client import BinanceFuturesClient
from ..validators import validate_symbol, validate_side, validate_qty
from ..logger import get_logger


@click.command(help="Emulated OCO for futures using TP and SL orders to close a position")
@click.argument("symbol")
@click.argument("side")
@click.argument("qty", type=float)
@click.argument("tp_price", type=float)
@click.argument("sl_price", type=float)
@click.option("--dry", is_flag=True, help="Dry run: validate and log without sending")
def cli(symbol: str, side: str, qty: float, tp_price: float, sl_price: float, dry: bool):
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    qty = validate_qty(qty)

    log = get_logger("oco")
    client = BinanceFuturesClient()
    if dry:
        log.info(f"DRY OCO {side} {symbol} qty={qty} tp={tp_price} sl={sl_price}")
        print(f"[yellow]Dry run: OCO {side} {symbol} qty={qty} tp={tp_price} sl={sl_price}")
        return

    resp = client.oco_take_profit_stop_loss(symbol, side, qty, tp_price, sl_price)
    print({"status": "ok", "response": resp})


if __name__ == "__main__":
    cli()
