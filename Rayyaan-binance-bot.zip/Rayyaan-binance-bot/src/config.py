from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv


@dataclass
class Settings:
    api_key: str
    api_secret: str
    testnet: bool
    default_symbol: str
    default_qty: float


def load_settings() -> Settings:
    # Load .env if present
    load_dotenv(override=False)
    api_key = os.getenv("BINANCE_API_KEY", "")
    api_secret = os.getenv("BINANCE_API_SECRET", "")
    testnet = os.getenv("BINANCE_FUTURES_TESTNET", "True").lower() in {"1", "true", "yes"}
    default_symbol = os.getenv("DEFAULT_SYMBOL", "BTCUSDT")
    default_qty = float(os.getenv("DEFAULT_QTY", "0.001"))
    return Settings(
        api_key=api_key,
        api_secret=api_secret,
        testnet=testnet,
        default_symbol=default_symbol,
        default_qty=default_qty,
    )
