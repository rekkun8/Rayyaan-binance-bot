from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_DOWN
from functools import lru_cache
from typing import Any, Dict, Optional

from .logger import get_logger


@dataclass
class SymbolFilters:
    tick_size: Decimal
    step_size: Decimal
    min_qty: Decimal
    min_price: Decimal
    market_step_size: Optional[Decimal] = None


log = get_logger("exchange")


def _to_decimal(s: str | float | int) -> Decimal:
    return Decimal(str(s))


@lru_cache(maxsize=256)
def get_symbol_filters(client, symbol: str) -> SymbolFilters:
    """Fetch and cache filters for a symbol from exchangeInfo.

    Works with Binance UMFutures client. Uses testnet/mainnet as configured on the client.
    """
    info: Dict[str, Any] = client.exchange_info()
    syms = info.get("symbols", [])
    s_up = symbol.upper()
    for s in syms:
        if s.get("symbol") == s_up:
            tick = Decimal("0.0")
            step = Decimal("0.0")
            market_step: Optional[Decimal] = None
            min_qty = Decimal("0.0")
            min_price = Decimal("0.0")
            for f in s.get("filters", []):
                t = f.get("filterType")
                if t == "PRICE_FILTER":
                    tick = _to_decimal(f.get("tickSize", "0"))
                    min_price = _to_decimal(f.get("minPrice", "0"))
                elif t == "LOT_SIZE":
                    step = _to_decimal(f.get("stepSize", "0"))
                    min_qty = _to_decimal(f.get("minQty", "0"))
                elif t == "MARKET_LOT_SIZE":
                    market_step = _to_decimal(f.get("stepSize", "0"))
            return SymbolFilters(
                tick_size=tick,
                step_size=step,
                min_qty=min_qty,
                min_price=min_price,
                market_step_size=market_step,
            )
    raise ValueError(f"Symbol {symbol} not found in exchange info")


def round_down(value: Decimal, quantum: Decimal) -> Decimal:
    if quantum == 0:
        return value
    # Quantize using exponent derived from quantum to avoid binary float issues
    q = value.quantize(quantum, rounding=ROUND_DOWN)
    return q


def adjust_price(client, symbol: str, price: float) -> float:
    f = get_symbol_filters(client, symbol)
    p = _to_decimal(price)
    if p < f.min_price:
        p = f.min_price
    if f.tick_size > 0:
        p = round_down(p, f.tick_size)
    return float(p)


def adjust_qty(client, symbol: str, qty: float, *, market: bool = False) -> float:
    f = get_symbol_filters(client, symbol)
    q = _to_decimal(qty)
    step = f.market_step_size if market and f.market_step_size else f.step_size
    if q < f.min_qty:
        q = f.min_qty
    if step and step > 0:
        q = round_down(q, step)
    return float(q)
