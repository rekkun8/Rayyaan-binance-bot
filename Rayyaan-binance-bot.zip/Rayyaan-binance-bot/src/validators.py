from __future__ import annotations

from typing import Literal

ALLOWED_SIDE = {"BUY", "SELL"}


def validate_symbol(symbol: str) -> str:
    s = symbol.upper().strip()
    if not s.endswith("USDT"):
        raise ValueError("Only USDT-M futures symbols are allowed (e.g., BTCUSDT)")
    if len(s) < 6:
        raise ValueError("Invalid symbol")
    return s


def validate_qty(qty: float) -> float:
    if qty <= 0:
        raise ValueError("Quantity must be > 0")
    return qty


def validate_side(side: str) -> Literal["BUY", "SELL"]:
    s = side.upper()
    if s not in ALLOWED_SIDE:
        raise ValueError("Side must be BUY or SELL")
    return s  # type: ignore[return-value]
