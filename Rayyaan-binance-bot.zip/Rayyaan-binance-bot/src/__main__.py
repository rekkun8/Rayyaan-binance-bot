from __future__ import annotations

import click

from .market_orders import cli as market_cli
from .limit_orders import cli as limit_cli
from .advanced.oco import cli as oco_cli
from .advanced.twap import cli as twap_cli
from .advanced.stop_limit import cli as stop_limit_cli
from .manage import cli as manage_cli


@click.group(help="Binance Futures Bot")
def main():
    pass


main.add_command(market_cli, name="market")
main.add_command(limit_cli, name="limit")
main.add_command(oco_cli, name="oco")
main.add_command(twap_cli, name="twap")
main.add_command(stop_limit_cli, name="stop-limit")
main.add_command(manage_cli, name="manage")


if __name__ == "__main__":
    main()
